# Windows 免安裝版（ChiaKey Portable）

仿照「偽蝦米」的做法：一個普通的 `ChiaKeyPortable.exe`，**不安裝、不寫登錄、不需要系統管理員權限**，
放在任何資料夾（含隨身碟）雙擊即可使用，刪除資料夾即移除。

> **狀態：實驗性。** 這個版本的程式碼已通過 Windows 目標的編譯檢查，且鍵盤路由邏輯有跨平台單元測試
> （`KeyRouterTest`），但**尚未在真實 Windows 上執行過**。請當成待驗證的草案。

## 與 TSF 版的差異

| | TSF 安裝版 | 免安裝版 |
|---|---|---|
| 與系統輸入法框架整合 | 是（註冊為 TSF 輸入法） | 否，一般程式 |
| 安裝／權限 | 需安裝、需註冊 | 免安裝、`asInvoker` |
| 取得按鍵 | TSF 回呼 | 全域低階鍵盤攔截（`WH_KEYBOARD_LL`） |
| 輸出文字 | TSF 組字 | 以 `SendInput`（`KEYEVENTF_UNICODE`）逐字送出 |
| 組字／候選字窗 | 系統管理 | 自繪浮動視窗，位置取自焦點視窗的插入點 |
| 引擎、詞庫、學習 | ChiaKeyCore | **同一份** ChiaKeyCore，沒有改動 |

TSF 版原始碼完全未改動；免安裝版是新增的 `ChiaKey-Source/Loaders/Windows-Portable/`，
並重用 `Windows-TSF` 中與 TSF 無關的檔案（引擎包裝、候選字窗、通知窗、輸出過濾等）。

## 使用

資料夾內容：

```
ChiaKeyPortable.exe
ChiaKeySource.db        詞庫（必須與 exe 同資料夾，否則不會啟動）
Data\                   使用者資料（學習、偏好；首次執行自動建立）
```

- 啟動後常駐系統匣，圖示會顯示目前輸入法（注／倉／簡）、英文（英）、暫停（停）、權限不足（禁）。
- 左鍵點圖示或 `Ctrl+Space`：中英切換。`Shift` 單擊：依偏好設定切換中英。
- `Shift+Space`：全形／半形。其餘快速鍵（換輸入法、簡繁輸出、重複上次輸入）沿用 TSF 版的設定。
- 右鍵選單：選輸入法、全形、簡體輸出、暫停、開啟資料資料夾、結束。
- 資料夾不可寫入（例如唯讀光碟）時，資料改放 `%LOCALAPPDATA%\ChiaKeyPortable\Data`。

## 在受管控的公司電腦上

免安裝版是為「不能安裝、沒有系統管理員權限」設計的：manifest 為 `asInvoker`，不寫登錄、不註冊 TSF，
引擎使用明確指定的路徑（exe 旁的 `Data\`），不會讀寫 `%APPDATA%\ChiaKey`，也不載入外部更新詞庫。
唯一的例外是 `Data\` 不可寫時改用 `%LOCALAPPDATA%\ChiaKeyPortable`（使用者自己的目錄，不需權限）。

但「不用安裝」不等於「一定能執行」，以下由公司的資安設定決定，程式本身無法繞過：

- **應用程式控制**（AppLocker、WDAC／Smart App Control）可能禁止執行未簽章或位於使用者可寫目錄的 exe。
- **EDR／防毒**可能把全域鍵盤攔截加 `SendInput` 視為鍵盤側錄而攔截或告警。
- **抽取式磁碟**可能被政策禁止執行程式。

遇到這些情況，請向資訊單位說明用途並申請白名單，不要試圖規避。

## 限制（請先讀）

- **高權限視窗**：以系統管理員身分執行的程式，一般權限的本程式無法對它送字（UIPI）。偵測到時會停止攔截
  並在圖示顯示「禁」，按鍵照常傳給該程式，不會吞鍵。需要時請以系統管理員身分執行本程式。
- **遊戲與反作弊**：全域鍵盤攔截與模擬輸入可能被遊戲或反作弊視為外掛。與偽蝦米相同，遊戲請先暫停或結束本程式。
- **防毒誤報**：未簽章、使用鍵盤攔截與 `SendInput` 的程式容易被誤判為鍵盤側錄，可能需要加入例外。
- **插入點位置**：Chrome、Electron、UWP 等不提供系統插入點的程式，組字窗會退而顯示在視窗底部中央。
- **不處理** `Alt`／`Win` 組合鍵；組字中切換到別的視窗會丟棄尚未送出的組字。
- 低階攔截若回應過慢會被系統無聲移除；程式在回呼過慢、解鎖、喚醒以及閒置時會自動重新掛上。
- 學習資料在引擎關閉時才寫入；程式會在閒置十秒後重建引擎以存檔，結束與登出時也會存檔，
  但被強制終止時最近的學習內容可能遺失。
- 未包含：標點符號鍵盤、符號視窗、設定介面、更新器、剪貼簿備援。偏好設定請沿用既有偏好檔或 TSF 版設定程式。
- 依賴按鍵送出的順序：快速連打時，組字結果以 `SendInput` 排入佇列，極端情況下可能與實體按鍵交錯。

## 建置

需要 Windows、Visual Studio（MSVC）、CMake ≥ 3.21。靜態連結 MSVC 執行階段，產出的 exe 不需要 VC redist。

```
cmake -S ChiaKey-Source/Loaders/Windows-Portable -B build-portable -A x64 -DCHIAKEY_LEXICON_DATABASE=<ChiaKeySource.db 路徑>
cmake --build build-portable --config Release
```

打包：`Packaging/Windows-Portable/make-portable-zip.ps1 -Build build-portable`，產出
`ChiaKey-Portable-<版本>-x64.zip`。

在非 Windows 上只會建置並執行 `KeyRouterTest`：

```
cmake -S ChiaKey-Source/Loaders/Windows-Portable -B /tmp/b && cmake --build /tmp/b && ctest --test-dir /tmp/b
```

## 檔案

- `PortableApp.cpp`：主程式——全域攔截、引擎串接、視窗協調、系統匣、看門狗。
- `KeyRouter.h`：與平台無關的按鍵路由規則（Shift 不吞、按下與放開成對吞、Shift 單擊判定），有單元測試。
- `TextOutput.cpp`：以 `VK_PACKET` 送出 Unicode，並暫時放開實體按住的 Ctrl；`ProcessOutranksUs` 判斷完整性層級。
- `PreeditWindow.cpp`：組字浮動視窗。 `TrayIcon.cpp`：執行期繪製的系統匣圖示。
- `PortablePaths.cpp`：定位 exe 旁的詞庫與資料夾。 `PortableStubs.cpp`：取代 TSF 更新器與模組控制代碼。
